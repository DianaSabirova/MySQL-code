


DROP DATABASE IF EXISTS vk;
CREATE DATABASE vk;
USE vk;


#
# TABLE STRUCTURE FOR: apps
#

DROP TABLE IF EXISTS `apps`;

CREATE TABLE `apps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_free` enum('free','paid') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_user_id` bigint(20) unsigned NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `apps_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('1', 'maxime', 'free', '1');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('2', 'sed', 'free', '2');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('3', 'facere', 'free', '3');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('4', 'unde', 'free', '4');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('5', 'quibusdam', 'paid', '5');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('6', 'exercitationem', 'paid', '6');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('7', 'velit', 'free', '7');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('8', 'consequatur', 'paid', '8');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('9', 'quaerat', 'paid', '9');
INSERT INTO `apps` (`id`, `name`, `is_free`, `admin_user_id`) VALUES ('10', 'sint', 'paid', '10');


#
# TABLE STRUCTURE FOR: communities
#

DROP TABLE IF EXISTS `communities`;

CREATE TABLE `communities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор сроки',
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Название группы',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Группы';

INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (1, 'optio', '1996-06-22 16:59:25', '1972-04-12 06:43:55');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (2, 'debitis', '1971-07-03 03:24:30', '1970-03-16 18:06:05');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (3, 'omnis', '2019-07-16 06:59:16', '1982-03-29 09:03:40');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (4, 'dignissimos', '1981-04-21 10:12:40', '2020-09-10 09:27:14');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (5, 'accusantium', '1996-08-04 19:25:13', '1985-02-27 18:24:02');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (6, 'ipsa', '2013-08-24 07:12:41', '2018-02-22 02:57:25');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (7, 'quia', '1975-12-07 02:07:24', '2005-10-27 03:48:25');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (8, 'sequi', '2013-01-25 00:31:59', '2022-03-14 08:15:00');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (9, 'iste', '1985-03-14 15:41:05', '1973-08-05 03:44:11');
INSERT INTO `communities` (`id`, `name`, `created_at`, `updated_at`) VALUES (10, 'dolore', '1992-12-18 03:06:32', '2012-01-03 18:30:59');


#
# TABLE STRUCTURE FOR: communities_users
#

DROP TABLE IF EXISTS `communities_users`;

CREATE TABLE `communities_users` (
  `community_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на группу',
  `user_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на пользователя',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  PRIMARY KEY (`community_id`,`user_id`) COMMENT 'Составной первичный ключ'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Участники групп, связь между пользователями и группами';

INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (1, 2, '1978-11-11 09:01:37');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (1, 8, '1989-03-12 02:28:13');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (1, 10, '2018-02-13 17:23:50');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (2, 3, '2021-03-31 11:56:54');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (3, 5, '1975-10-01 23:46:31');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (3, 6, '1984-11-28 14:19:21');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (3, 7, '1994-10-02 10:04:54');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (5, 4, '2016-03-13 03:29:21');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (5, 9, '1986-05-02 20:45:50');
INSERT INTO `communities_users` (`community_id`, `user_id`, `created_at`) VALUES (10, 1, '2003-03-23 08:50:55');


#
# TABLE STRUCTURE FOR: friendship
#

DROP TABLE IF EXISTS `friendship`;

CREATE TABLE `friendship` (
  `user_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на инициатора дружеских отношений',
  `friend_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на получателя приглашения дружить',
  `status_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на статус (текущее состояние) отношений',
  `requested_at` datetime DEFAULT current_timestamp() COMMENT 'Время отправления приглашения дружить',
  `confirmed_at` datetime DEFAULT NULL COMMENT 'Время подтверждения приглашения',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`user_id`,`friend_id`) COMMENT 'Составной первичный ключ'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Таблица дружбы';

INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (1, 1, 11, '1983-08-22 11:32:37', '1975-07-29 18:28:22', '1989-09-03 17:30:48', '2020-01-28 15:27:06');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (2, 2, 12, '2002-05-31 11:16:10', '1993-04-25 06:02:17', '1977-04-23 16:40:33', '1972-01-12 16:22:44');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (3, 3, 13, '1981-05-25 12:42:13', '1978-02-10 18:52:05', '1992-07-22 01:56:03', '2005-08-18 19:29:47');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (4, 4, 15, '2013-12-15 16:35:31', '1996-12-03 07:21:42', '1992-04-26 13:38:50', '1975-09-03 10:37:23');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (5, 5, 16, '1979-08-20 08:01:03', '1983-08-08 02:56:57', '1989-09-23 19:36:43', '1989-02-04 19:06:14');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (6, 6, 17, '2012-12-02 09:45:43', '2005-09-17 13:53:11', '2008-04-08 20:48:43', '2006-10-28 09:48:09');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (7, 7, 19, '1995-05-13 10:44:16', '2008-06-26 00:57:34', '1981-06-26 00:08:31', '1980-09-18 11:54:11');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (8, 8, 20, '1991-10-15 19:02:22', '1985-10-03 17:12:05', '1977-12-13 12:39:11', '1977-12-31 06:00:56');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (9, 9, 11, '1988-12-16 05:52:11', '1999-09-01 15:10:51', '1979-03-27 17:00:31', '1985-06-19 08:38:21');
INSERT INTO `friendship` (`user_id`, `friend_id`, `status_id`, `requested_at`, `confirmed_at`, `created_at`, `updated_at`) VALUES (10, 10, 12, '1990-09-16 21:11:21', '1990-12-23 16:25:02', '2007-05-26 08:34:28', '1974-03-21 10:15:44');


#
# TABLE STRUCTURE FOR: friendship_statuses
#

DROP TABLE IF EXISTS `friendship_statuses`;

CREATE TABLE `friendship_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор строки',
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Название статуса',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Статусы дружбы';

INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (11, 'vel', '2007-05-16 07:11:39', '2018-12-17 08:03:11');
INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (12, 'ratione', '2022-05-10 15:22:23', '1981-07-08 10:32:36');
INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (13, 'consequatur', '1970-07-28 01:57:35', '2010-06-26 11:29:57');
INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (15, 'est', '1972-05-10 10:32:34', '2014-04-23 19:21:43');
INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (16, 'non', '1976-05-12 12:14:24', '1988-10-09 16:45:18');
INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (17, 'dolor', '2011-07-07 03:15:34', '2006-11-17 22:37:44');
INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (19, 'amet', '2009-05-28 11:49:45', '1975-03-08 20:53:17');
INSERT INTO `friendship_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES (20, 'voluptatem', '1993-06-14 19:25:41', '1983-12-18 08:43:36');


#
# TABLE STRUCTURE FOR: likes
#

DROP TABLE IF EXISTS `likes`;

CREATE TABLE `likes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `target_type` enum('post','photo','user') COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('1', '1', '2011-01-21 15:55:08', 'photo', '1');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('2', '2', '1971-07-14 06:32:42', 'user', '2');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('3', '3', '1973-11-23 00:23:16', 'photo', '3');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('4', '4', '1973-10-15 05:13:59', 'user', '4');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('5', '5', '1991-12-25 12:35:13', 'user', '5');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('6', '6', '2000-08-10 15:46:34', 'post', '6');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('7', '7', '1973-01-15 19:07:01', 'user', '7');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('8', '8', '1982-10-12 07:34:24', 'post', '8');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('9', '9', '1993-10-02 20:31:25', 'user', '9');
INSERT INTO `likes` (`id`, `user_id`, `created_at`, `target_type`, `target_id`) VALUES ('10', '10', '1997-04-20 17:59:05', 'post', '10');


#
# TABLE STRUCTURE FOR: media
#

DROP TABLE IF EXISTS `media`;

CREATE TABLE `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор строки',
  `user_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на пользователя, который загрузил файл',
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Путь к файлу',
  `size` int(11) NOT NULL COMMENT 'Размер файла',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Метаданные файла' CHECK (json_valid(`metadata`)),
  `media_type_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на тип контента',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Медиафайлы';

INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (1, 1, 'id', 2, NULL, 1, '1979-12-26 20:33:41', '1985-09-15 20:01:27');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (2, 2, 'enim', 7570, NULL, 2, '2018-03-28 08:25:24', '2019-02-07 04:27:57');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (3, 3, 'doloremque', 562303103, NULL, 3, '1997-05-12 00:04:37', '2022-01-09 13:02:42');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (4, 4, 'ullam', 89, NULL, 4, '2001-03-26 23:18:57', '2013-09-08 19:10:58');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (5, 5, 'veniam', 67822171, NULL, 5, '1993-05-25 04:29:05', '2019-11-02 15:25:01');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (6, 6, 'atque', 7465567, NULL, 6, '2004-08-12 19:35:45', '1975-04-11 17:02:25');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (7, 7, 'omnis', 0, NULL, 7, '1993-10-19 02:01:44', '2016-12-07 05:30:20');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (8, 8, 'est', 217887, NULL, 8, '2014-06-20 17:19:19', '1984-03-19 18:40:19');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (9, 9, 'sint', 187, NULL, 9, '1980-12-12 23:54:41', '2013-11-14 06:07:59');
INSERT INTO `media` (`id`, `user_id`, `filename`, `size`, `metadata`, `media_type_id`, `created_at`, `updated_at`) VALUES (10, 10, 'mollitia', 677351, NULL, 10, '1988-11-15 21:06:11', '1983-01-05 00:09:29');


#
# TABLE STRUCTURE FOR: media_types
#

DROP TABLE IF EXISTS `media_types`;

CREATE TABLE `media_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор строки',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Название типа',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Типы медиафайлов';

INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (1, 'perspiciatis', '2000-10-19 19:15:44', '1984-05-20 00:44:05');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (2, 'dolor', '1988-06-01 18:45:36', '1991-11-17 07:16:15');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (3, 'exercitationem', '1985-01-01 15:54:05', '2017-09-26 14:14:29');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (4, 'eligendi', '2011-05-11 17:12:02', '2022-06-30 16:53:47');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (5, 'maiores', '2000-10-25 12:56:20', '1991-05-07 03:39:24');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (6, 'autem', '1997-08-04 12:41:18', '1990-12-24 18:04:38');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (7, 'rerum', '1994-01-13 19:40:40', '1980-08-06 02:03:38');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (8, 'quasi', '1984-03-09 19:35:17', '1996-03-15 10:09:25');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (9, 'aspernatur', '2017-09-24 21:44:07', '1977-08-15 05:18:33');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (10, 'ut', '1988-08-28 17:51:13', '1998-06-28 17:10:07');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор строки',
  `from_user_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на отправителя сообщения',
  `to_user_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на получателя сообщения',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Текст сообщения',
  `is_important` tinyint(1) DEFAULT NULL COMMENT 'Признак важности',
  `is_delivered` tinyint(1) DEFAULT NULL COMMENT 'Признак доставки',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Сообщения';

INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (1, 1, 1, 'At nisi at ullam quia quia. Pariatur ut dolor dolores animi consequuntur impedit ut. Animi asperiores debitis quo corporis. Autem laudantium consequatur et in qui illum doloribus.', 0, 0, '2009-10-28 14:57:21', '1995-04-18 10:20:59');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (2, 2, 2, 'Aut voluptatem aut dolores perspiciatis saepe in. Architecto dolorem molestias hic illo dicta nulla. Est accusantium sunt deleniti. Veritatis nesciunt qui autem voluptas et voluptas.', 0, 1, '2009-09-09 00:19:00', '1971-02-22 15:33:22');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (3, 3, 3, 'Molestiae sunt hic iusto autem quam iste. Neque ea reprehenderit incidunt molestiae consequatur in. Culpa in ea tempore. Eligendi et et quasi voluptatem.', 1, 1, '1995-11-25 08:22:38', '2018-08-01 05:53:33');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (4, 4, 4, 'Dolor omnis consequatur eos. Velit aut quibusdam voluptatem iure accusamus. Consequatur eligendi similique qui quod.', 0, 1, '1996-09-23 06:30:16', '2000-07-01 13:58:04');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (5, 5, 5, 'Officia illo vitae excepturi sapiente sit et aliquam. Eaque repellendus modi doloribus ea doloremque. Odit impedit perferendis et eum est est voluptas.', 0, 0, '1975-07-24 20:09:13', '1982-07-11 19:30:46');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (6, 6, 6, 'Qui sint ipsum quia quae veritatis. Qui dolorum in magni dicta quo consequuntur. Similique dolores quo debitis rerum libero velit voluptates. Et eius fugit dolore soluta in molestiae aut labore.', 1, 0, '1990-06-14 02:15:09', '2016-05-27 06:49:55');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (7, 7, 7, 'Doloremque quas incidunt optio aut non est. Corporis voluptatum illum praesentium impedit. Ex in laudantium dolorem at. Quis ea ut iusto ea accusamus incidunt molestiae.', 1, 0, '1994-10-08 10:30:37', '1985-07-16 21:21:26');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (8, 8, 8, 'Delectus quia debitis nam eius nihil ad adipisci corrupti. Molestias doloremque blanditiis quas quis sed. Architecto laudantium consectetur enim voluptatem nam dolores vel temporibus.', 1, 1, '1981-05-30 06:58:50', '2013-02-04 05:58:26');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (9, 9, 9, 'Beatae tempora occaecati perferendis exercitationem. Nemo doloribus at ad ea saepe est quidem. Enim quod nemo id iste maiores minus. Repudiandae atque fuga eum nihil qui.', 0, 0, '2013-03-13 04:24:26', '1973-10-23 16:57:14');
INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `body`, `is_important`, `is_delivered`, `created_at`, `updated_at`) VALUES (10, 10, 10, 'Commodi sequi delectus nisi ipsam. Hic enim quos sunt et qui velit. Magnam laboriosam voluptatem omnis quia. Itaque enim repudiandae deleniti.', 0, 1, '1993-12-19 07:37:59', '1972-10-29 23:43:17');


#
# TABLE STRUCTURE FOR: online_status
#

DROP TABLE IF EXISTS `online_status`;

CREATE TABLE `online_status` (
  `active_user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status_online_user` enum('Online','MobileOnline','Ofline') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `update_time` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`active_user_id`),
  KEY `status_online_user` (`status_online_user`),
  KEY `update_time` (`update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='таблица активности пользователя';

INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('1', 'Online', '1975-01-11 02:56:00');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('2', 'MobileOnline', '2013-12-10 06:16:45');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('3', 'Ofline', '2007-01-25 18:43:13');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('4', 'MobileOnline', '1995-11-17 20:41:48');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('5', 'Ofline', '1971-03-28 20:56:44');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('6', 'MobileOnline', '2002-02-13 13:26:50');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('7', 'MobileOnline', '1990-10-24 11:05:53');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('8', 'MobileOnline', '1980-03-15 00:09:34');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('9', 'Ofline', '1992-08-29 15:35:07');
INSERT INTO `online_status` (`active_user_id`, `status_online_user`, `update_time`) VALUES ('10', 'Ofline', '2001-08-30 21:36:35');


#
# TABLE STRUCTURE FOR: profiles
#

DROP TABLE IF EXISTS `profiles`;

CREATE TABLE `profiles` (
  `user_id` int(10) unsigned NOT NULL COMMENT 'Ссылка на пользователя',
  `gender` char(1) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Пол',
  `birthday` date DEFAULT NULL COMMENT 'Дата рождения',
  `photo_id` int(10) unsigned DEFAULT NULL COMMENT 'Ссылка на основную фотографию пользователя',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Текущий статус',
  `city` varchar(130) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Город проживания',
  `country` varchar(130) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Страна проживания',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Профили';

INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (1, '', '2004-01-15', 1, 'Qui aperiam voluptas accusamus', 'Daynehaven', '357079568', '2001-01-14 20:26:28', '1995-11-20 22:24:09');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (2, '', '1970-11-22', 2, 'Odit sit velit quam ab fugit h', 'Hardymouth', '66', '2012-08-03 04:13:50', '2022-08-14 15:38:01');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (3, '', '2019-12-04', 3, 'Praesentium nemo facilis tenet', 'Schneidertown', '9', '1987-10-23 02:18:40', '1995-02-21 19:48:08');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (4, '', '1991-08-20', 4, 'Illo corrupti magni molestiae ', 'Lucaschester', '2073827', '1993-05-20 00:38:30', '2018-08-09 17:32:15');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (5, '', '2000-08-01', 5, 'Odit atque nesciunt doloribus.', 'Schultzville', '461', '2015-11-10 18:34:16', '2015-04-11 16:26:54');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (6, '', '1995-03-30', 6, 'Voluptatem quisquam dolores qu', 'Pfannerstillburgh', '4180', '1975-01-25 05:08:37', '1971-08-10 15:27:25');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (7, '', '2021-05-23', 7, 'In quia et magni tempora optio', 'West Kirsten', '6035270', '2008-01-16 22:35:51', '2018-09-14 10:31:16');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (8, '', '1995-03-18', 8, 'Neque sed et qui iure fugiat u', 'South Cartermouth', '31786', '1986-06-16 08:56:51', '1985-11-03 08:28:55');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (9, '', '1981-11-09', 9, 'Ipsam consequatur corporis eos', 'West Kamren', '3473421', '1989-02-14 16:05:10', '2000-07-13 23:50:38');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `photo_id`, `status`, `city`, `country`, `created_at`, `updated_at`) VALUES (10, '', '1970-04-01', 10, 'Velit animi ipsam sunt volupta', 'Wiegandtown', '1', '1997-06-14 16:28:30', '2015-06-11 00:08:37');


#
# TABLE STRUCTURE FOR: status
#

DROP TABLE IF EXISTS `status`;

CREATE TABLE `status` (
  `status_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('1', 'Beatae aspernatur non molestiae et. Sit provident voluptate libero natus sed sint. Blanditiis quibusdam expedita deleniti.', '1992-06-30 13:12:47');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('2', 'Qui quibusdam tenetur facere ratione consequatur rerum sit et. Velit quos dignissimos eum laborum assumenda recusandae et quis. Voluptatem cumque et aut qui quos omnis voluptatibus.', '2000-05-24 22:07:18');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('3', 'Aut sed in quod laborum sed odit. Praesentium autem quasi id ab eos temporibus saepe. Ad ea et occaecati quam dolor nam temporibus vitae. Libero sapiente ullam quis beatae sed rerum.', '2003-12-15 19:43:02');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('4', 'Non omnis necessitatibus dolorum rerum aspernatur. Eius dolor voluptas quod aut nesciunt saepe. Fugit accusantium nihil minus earum id.', '2000-09-10 20:47:33');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('5', 'Voluptate doloribus sequi voluptas et modi eum placeat. Asperiores minus perspiciatis sequi dolorem autem beatae. Dolorum iusto et repellat aut dolorem qui.', '1970-01-08 22:01:44');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('6', 'Molestiae nostrum saepe non nemo eligendi. Vero consequatur tempora ut consequatur quae nostrum. Aut enim exercitationem porro. Dignissimos deserunt voluptatem in veniam nulla dolor unde.', '1997-08-09 09:50:44');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('7', 'Sit deserunt velit aliquid. Sit natus qui ipsum doloribus dolor ut. Porro dolore ipsum non rerum velit quae sed.', '2013-06-10 12:21:04');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('8', 'Quam veritatis in voluptate et inventore. Corrupti expedita sed deleniti veniam.', '2011-01-13 06:01:23');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('9', 'Exercitationem quos consectetur vel ducimus culpa quasi. Ducimus beatae quos consequuntur veniam vitae iure et. Repudiandae est harum eius expedita exercitationem.', '1994-06-28 02:18:19');
INSERT INTO `status` (`status_id`, `body`, `created_at`) VALUES ('10', 'Sunt consequatur laborum hic sit eius officiis ipsam. Odio perferendis quasi molestias corporis consequatur. Dolores molestias sed omnis delectus ex magnam. Rerum quia quaerat rerum dolorum voluptatem nostrum est.', '2001-12-05 20:22:04');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор строки',
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Имя пользователя',
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Фамилия пользователя',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Почта',
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Телефон',
  `created_at` datetime DEFAULT current_timestamp() COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Пользователи';

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (1, 'Elvis', 'Hessel', 'tmclaughlin@example.net', '(555)324-1843x62140', '1991-02-08 06:34:28', '2006-08-03 17:30:25');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (2, 'Darrel', 'Hills', 'rolfson.obie@example.org', '857-966-4903x5744', '1972-10-16 05:33:36', '1980-10-11 03:20:47');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (3, 'Jazlyn', 'Jenkins', 'windler.sister@example.net', '03653191806', '1994-02-07 09:46:33', '1983-02-05 01:50:57');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (4, 'Trycia', 'Hettinger', 'emmet.zboncak@example.net', '+89(7)7047732427', '1981-05-03 13:21:49', '1970-04-15 16:50:08');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (5, 'Brionna', 'Smitham', 'johnathan.graham@example.org', '(805)725-0368x7972', '1977-11-19 23:05:29', '2004-12-15 03:35:05');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (6, 'Ursula', 'Hoppe', 'dallin.smitham@example.org', '1-227-586-4111x238', '1992-12-10 11:45:54', '1996-10-22 22:08:43');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (7, 'Alanna', 'Kling', 'zbartell@example.net', '029.063.8888x2721', '2022-04-10 01:36:03', '2000-05-12 00:27:22');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (8, 'Stephen', 'Medhurst', 'o\'hara.alvina@example.com', '(605)091-2199x02427', '2006-03-08 12:32:34', '1991-05-31 21:25:42');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (9, 'Camilla', 'Legros', 'arowe@example.org', '267-556-0299x1380', '1990-04-01 00:12:21', '2005-06-28 16:49:31');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (10, 'Tremaine', 'Bednar', 'maximus.bashirian@example.org', '918.617.1624x6573', '1978-10-01 01:29:19', '1998-11-24 02:33:26');


#
# TABLE STRUCTURE FOR: users_apps
#

DROP TABLE IF EXISTS `users_apps`;

CREATE TABLE `users_apps` (
  `user_id` bigint(20) unsigned NOT NULL,
  `apps_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`apps_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('1', '1');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('2', '2');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('3', '3');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('4', '4');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('5', '5');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('6', '6');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('7', '7');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('8', '8');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('9', '9');
INSERT INTO `users_apps` (`user_id`, `apps_id`) VALUES ('10', '10');

