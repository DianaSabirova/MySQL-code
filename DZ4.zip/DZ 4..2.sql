USE vk;
SHOW TABLES;

-- ------------------------------------ users -----------------------------

DESC users;

-- Приводим в порядок временные метки
UPDATE users SET updated_at = NOW() WHERE updated_at < created_at;

SELECT * FROM users LIMIT 10;


-- ----------------------------- profiles -----------------------------------

DESC profiles;

-- Поправим столбец пола
DROP TEMPORARY TABLE IF EXISTS genders;
CREATE TEMPORARY TABLE genders (name CHAR(1));
INSERT INTO genders VALUES ('M'), ('F');
SELECT * FROM genders;

-- Обновляем пол
UPDATE profiles SET gender = (SELECT name FROM genders ORDER BY RAND() LIMIT 1);

-- Приводим в порядок временные метки
UPDATE profiles SET updated_at = NOW() WHERE updated_at < created_at;

-- Ограничиваем кол-во стран до 200
UPDATE profiles SET country = FLOOR(1 + RAND() * 200); 


SELECT * FROM profiles LIMIT 10;


-- ------------------------------- messages --------------------------------

DESC messages;

-- Обновляем значения ссылок на отправителя и получателя сообщения
UPDATE messages SET
from_user_id = FLOOR(1 + RAND() * 100),
to_user_id = FLOOR(1 + RAND() * 100);

-- Приводим в порядок временные метки
UPDATE messages SET updated_at = NOW() WHERE updated_at < created_at;


SELECT * FROM messages LIMIT 10;

-- ---------------------------------- media ---------------------------------------------


DESC media;

-- Обновляем ссылку на пользователя - владельца
UPDATE media SET user_id = FLOOR(1 + RAND() * 100);


-- Создаём временную таблицу форматов медиафайлов
DROP TEMPORARY TABLE IF EXISTS extensions; 
CREATE TEMPORARY TABLE extensions (name VARCHAR(10));


-- заполняем значениями
INSERT INTO extensions VALUES ('jpeg'), ('avi'), ('mpeg'), ('png');
SELECT * FROM extensions LIMIT 10;


-- Обновляем ссылку на файл
UPDATE media SET filename = CONCAT(
  'http://dropbox.net/vk/',
  filename,
  '.',
  (SELECT name FROM extensions ORDER BY RAND() LIMIT 1)
);

-- Обновляем размер файлов
UPDATE media SET size = FLOOR(10000 + (RAND() * 1000000)) WHERE size < 1000;

-- Заполняем метаданные
UPDATE media SET metadata = CONCAT('{"owner":"', 
  (SELECT CONCAT(first_name, ' ', last_name) FROM users WHERE id = user_id),
  '"}');  

-- Возвращаем столбцу метеданных правильный тип
ALTER TABLE media MODIFY COLUMN metadata JSON;

SELECT * FROM media LIMIT 10;

-- -------------------------------------- media_type_id -------------------------------------

DESC media_types;


-- Приводим в порядок временные метки
UPDATE media_types SET updated_at = NOW() WHERE updated_at < created_at;


-- Анализируем, понимаем, что нужно сделать только 3 типа медиа.
SELECT * FROM media_types LIMIT 10;


-- Удаляем все типы, вписываем только нужные

-- DELETE не сбрасывает счетчик аутоинкримента, поэтому применяем TRUNCATE

TRUNCATE media_types;

INSERT INTO media_types (name) VALUES
('photo'),
('video'),
('audio')
;

-- DELETE не сбрасывает счетчик аутоинкримента, поэтому применяем TRUNCATE
SELECT * FROM media_types LIMIT 10;

-- ------------------------------------- Возвращаемся к media -------------------------------

-- Анализируем media
UPDATE media SET media_type_id = FLOOR(1 + RAND() * 3)

SELECT * FROM media;




-- -------------------------------------- friendship ----------------------------------------
-- смотрим структуру данных friendship
DESC friendship;

-- id отправителя и получателя равны. Вписывая ранодомное значение.
-- Прибавляем 1 если, т.к id под 0 номером не должно существовать.

UPDATE friendship SET user_id = FLOOR(1 + RAND() * 100), friend_id = FLOOR(1 + RAND() * 100);

-- Исправляем если id отправителя и получателя равны

UPDATE friendship SET
friend_id = friend_id + 1 WHERE user_id = friend_id;

-- created_at самый ранний. Создание 
-- requested. Запрос
-- confirmed. Подтверждение
-- update самый поздний. Обновление


-- Приводим в порядок временные метки
UPDATE friendship SET updated_at = NOW() WHERE updated_at < created_at;

-- Обновляем ссылки на статус 
UPDATE friendship SET status_id = FLOOR(1 + RAND() * 3); 

SELECT * FROM friendship WHERE updated_at < confirmed_at < requested_at < created_at;



-- -------------------------------- friendship statuses------------------------------------

-- Анализируем данные 
SELECT * FROM friendship_statuses;

-- Очищаем таблицу
TRUNCATE friendship_statuses;

-- Вставляем значения статусов дружбы
INSERT INTO friendship_statuses (name) VALUES
  ('Requested'),
  ('Confirmed'),
  ('Rejected');
 
-- Обновляем ссылки на статус 
UPDATE friendship SET status_id = FLOOR(1 + RAND() * 3); 
-- Анализируем данные 
SELECT * FROM friendship_statuses;

-- -------------------------------- Communities ---------------------------------

-- Смотрим структуру таблицы групп
DESC communities;


-- Приводим в порядок временные метки
UPDATE communities SET updated_at = NOW() WHERE updated_at < created_at;

-- Удаляем часть групп
DELETE FROM communities WHERE id > 20;

-- Анализируем таблицу связи пользователей и групп
SELECT * FROM communities_users;

-- Обновляем значения community_id
UPDATE communities_users SET community_id = FLOOR(1 + RAND() * 20);
DELETE FROM communities_users WHERE community_id > 100;

SELECT * FROM communities;












