/*
3.
В таблице складских запасов storehouses_products в поле value могут встречаться самые разные цифры: 
0, если товар закончился
и выше нуля, если на складе имеются запасы.
Необходимо отсортировать записи таким образом, чтобы они выводились в порядке увеличения значения value. 
Однако нулевые запасы должны выводиться в конце, после всех записей.
*/


DROP DATABASE IF EXISTS store;
CREATE DATABASE store;
USE store;


DROP TABLE IF EXISTS `storehouses_products`;
CREATE TABLE storehouses_products
( storehouse_id VARCHAR(250) NOT NULL,
  product_id INT PRIMARY KEY,
  value INT, 
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT NOW() ON UPDATE NOW()
);

DESC storehouses_products;

INSERT INTO storehouses_products VALUES
(1, 1, 0, NOW(),NOW()),
(1, 2, 1, NOW(),NOW()),
(1, 3, 2, NOW(),NOW()),
(1, 4, 3, NOW(),NOW()),
(1, 5, 4, NOW(),NOW()),
(1, 6, 5, NOW(),NOW()),
(1, 7, 0, NOW(),NOW()),
(1, 8, 1, NOW(),NOW()),
(1, 9, 2, NOW(),NOW()),
(1, 10, 3, NOW(),NOW());

SELECT storehouse_id, product_id, value, created_at, updated_at FROM storehouses_products 
ORDER BY 
CASE WHEN value = 0
     THEN 9999999999999999999999
     ELSE value END;




-- 4.(по желанию) Из таблицы users необходимо извлечь пользователей, родившихся в августе и мае. Месяцы заданы в виде списка английских названий (may, august)

USE vk;
DESC users; -- нет колонки даты рождения
ALTER TABLE users ADD COLUMN date_of_birth DATE NOT NULL;

DESC users;
DELETE FROM users 

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (1, 'Lionel', 'Schmeler', 'lois74@example.com', '(083)691-6952x84720', '1987-07-22 11:22:58', '2008-08-30 07:32:37', '1993-08-23');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (2, 'Mortimer', 'Weissnat', 'ymiller@example.org', '368-237-7954', '2005-01-30 00:19:21', '2019-04-20 04:30:32', '2017-08-07');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (3, 'Susana', 'Emmerich', 'luis91@example.net', '06174298196', '1977-10-05 22:22:10', '1975-09-20 05:28:38', '2008-10-18');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (4, 'Mac', 'Pagac', 'pierre.kuhic@example.net', '(377)423-9334x02047', '1970-03-09 08:31:28', '1987-12-14 00:19:11', '1970-10-05');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (5, 'Imogene', 'Stoltenberg', 'ola.torp@example.com', '(872)037-5604x2272', '1982-03-14 10:59:44', '1985-12-04 23:10:25', '1983-07-09');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (6, 'Eino', 'Carroll', 'ludie.johns@example.net', '202-812-8819', '2000-01-23 20:01:33', '1987-09-09 18:37:45', '2011-09-22');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (7, 'Sim', 'Kassulke', 'dheaney@example.com', '(430)056-4137x446', '1988-08-27 13:50:36', '2003-09-02 05:23:18', '2022-06-16');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (8, 'Mauricio', 'Langworth', 'ines00@example.com', '468.388.2765x5729', '2006-07-21 03:00:17', '1996-04-22 11:08:10', '1970-06-10');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (9, 'Deontae', 'Auer', 'zleuschke@example.com', '1-533-627-5639x671', '1982-09-14 18:03:14', '1973-11-20 21:21:50', '1979-10-21');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`, `date_of_birth`) VALUES (10, 'Nestor', 'Wehner', 'agulgowski@example.com', '837.523.2862', '2022-04-21 16:49:10', '1980-12-03 07:33:09', '2017-05-19');
SELECT * FROM users;


SELECT id, first_name, date_of_birth, DATE_FORMAT(date_of_birth, '%m') in ('05','08') as new_dt FROM users;


-- 5. (по желанию) Из таблицы catalogs извлекаются записи при помощи запроса. SELECT * FROM catalogs WHERE id IN (5, 1, 2); Отсортируйте записи в порядке, заданном в списке IN.

DROP DATABASE IF EXISTS shop;
CREATE DATABASE shop;
USE shop;


DROP TABLE IF EXISTS `catalogs`;
CREATE TABLE `catalogs` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `catalogs` (`id`) VALUES (0);
INSERT INTO `catalogs` (`id`) VALUES (1);
INSERT INTO `catalogs` (`id`) VALUES (2);
INSERT INTO `catalogs` (`id`) VALUES (3);
INSERT INTO `catalogs` (`id`) VALUES (4);
INSERT INTO `catalogs` (`id`) VALUES (5);
INSERT INTO `catalogs` (`id`) VALUES (6);
INSERT INTO `catalogs` (`id`) VALUES (7);
INSERT INTO `catalogs` (`id`) VALUES (8);
INSERT INTO `catalogs` (`id`) VALUES (9);



SELECT * FROM catalogs WHERE id IN (5, 1, 2) 
ORDER BY CASE
    WHEN id = 3 THEN 0
    WHEN id = 1 THEN 1
    WHEN id = 2 THEN 2
END;



























