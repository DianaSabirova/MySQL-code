--Практическое задание теме «Агрегация данных»
--1.  Подсчитайте средний возраст пользователей в таблице users.


USE vk;
SELECT date_of_birth FROM users;
SELECT ROUND(AVG((TO_DAYS(NOW()) - TO_DAYS(date_of_birth)) / 365.25), 0) AS avg_age FROM users;




--2.  Подсчитайте количество дней рождения, которые приходятся на каждый из дней недели. Следует учесть, что необходимы дни недели текущего года, а не года рождения.





--3.  (по желанию) Подсчитайте произведение чисел в столбце таблицы.

USE store;

DROP TABLE IF EXISTS `integers`;

CREATE TABLE `integers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `integers` (`id`, `value`) VALUES ('1', 1);
INSERT INTO `integers` (`id`, `value`) VALUES ('2', 2);
INSERT INTO `integers` (`id`, `value`) VALUES ('3', 3);
INSERT INTO `integers` (`id`, `value`) VALUES ('4', 4);
INSERT INTO `integers` (`id`, `value`) VALUES ('5', 5);




SELECT EXP(SUM(LN(value))) from integers;