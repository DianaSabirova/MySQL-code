

/*
Практическое задание по теме “Операторы, фильтрация, сортировка и ограничение”

 1. Пусть в таблице users поля created_at и updated_at оказались незаполненными. Заполните их текущими датой и временем.
*/

USE vk;

UPDATE users SET created_at = NOW() AND updated_at = NOW();
SELECT * FROM users;



/*2. Таблица users была неудачно спроектирована. Записи created_at и updated_at были заданы
     типом VARCHAR и в них долгое время помещались значения в формате "20.10.2017 8:10".
     Необходимо преобразовать поля к типу DATETIME, сохранив введеные ранее значения.
*/

DESC users;  -- проверяем к какому типу данных относяться created_at и updated_at
/*MySQL функция STR_TO_DATE преобразует строку в дату, определенного формата.
STR_TO_DATE( string, format_mask )
*/
-- Функция STR_TO_DATETIME меняет формат вывода, но не сам тип данных VARCHAR


ALTER TABLE users ADD COLUMN created_at_new DATETIME ;
ALTER TABLE users ADD COLUMN updated_at_new DATETIME ; -- создадим дополнительные столбцы для переброса данных в правильный формат DATETIME
UPDATE users SET created_at_new = STR_TO_DATE(created_at, '%d.%m.%Y %h:%i');  -- с помощью этой функции сохраняем предыдущее время 
UPDATE users SET updated_at_new = STR_TO_DATE(updated_at, '%d.%m.%Y %h:%i');
ALTER TABLE users 
    DROP created_at, DROP updated_at, 
    RENAME COLUMN created_at_new TO created_at, RENAME COLUMN updated_at_new TO updated_at;
    
SELECT * FROM users;
   
   
   
   
   
   
   
   
   
   
   
   